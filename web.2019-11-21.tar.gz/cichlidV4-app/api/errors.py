def bad_request():
    pass

