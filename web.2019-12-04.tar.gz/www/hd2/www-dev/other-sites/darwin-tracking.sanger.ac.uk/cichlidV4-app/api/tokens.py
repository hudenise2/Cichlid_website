def get_token():
    pass

def revoke_token():
    pass
